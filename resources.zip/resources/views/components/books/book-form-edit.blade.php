@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="POST" action="{{ url('admin/books/' . $book->id)  }}">
                        @csrf
                        @method('PUT')
                        <div class="card ">

                            <div class="card-header card-header-primary">
                                <h4 class="card-title">{{ __('Edit Book') }}</h4>
                                <p class="card-category">{{ __('Book information') }}</p>
                            </div>

                            <div class="card-body">
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Title') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input
                                                type="text"
                                                id="title"
                                                name="title"
                                                autocomplete="title"
                                                placeholder="title"
                                                class="form-control
                                                 @error('title') is-invalid @enderror"
                                                value="{{ $book->title }}"
                                                required
                                                aria-describedby="nameHelp">

                                            @error('title')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Author') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <select name="author_id[]" class="form-control" multiple style="height:230px">
                                                {{$currentBookAuthors[] = ''}}
                                                @foreach($book->authors as $currentAuthor)
                                                    {{$currentBookAuthors[] = $currentAuthor->id}}
                                                @endforeach
                                                @foreach($authors as $newAuthor)
                                                    @if(in_array($newAuthor->id, $currentBookAuthors))
                                                        <option selected value = {{ $newAuthor->id }} >
                                                            {{ $newAuthor->first_name }} {{ $newAuthor->last_name }}
                                                        </option>
                                                    @else
                                                        <option value = {{ $newAuthor->id }} >
                                                            {{ $newAuthor->first_name }} {{ $newAuthor->last_name }}
                                                        </option>
                                                    @endif
                                                @endforeach
                                            </select>
                                            @error('author')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Description') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <textarea
                                                type="text"
                                                rows="6"
                                                id="description"
                                                name="description"
                                                autocomplete="description"
                                                class="form-control
                                                @error('description') is-invalid @enderror"
                                                required
                                                aria-describedby="nameHelp">{{$book->description}}</textarea>
                                            @error('description')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Read Time (Min)') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input
                                                type="text"
                                                id="read_time"
                                                name="read_time"
                                                autocomplete="read_time"
                                                placeholder="Estimated reading time in minutes"
                                                class="form-control @error('read time') is-invalid @enderror"
                                                value="{{ $book->read_time }}"
                                                required
                                                aria-describedby="nameHelp">
                                            @error('read_time')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Age Group (Years)') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <select name="age_group_id" class="form-control">
                                                    <option selected value = {{ $book->age_group_id }} >
                                                        {{ $book->ageGroup->age_group }}
                                                    </option>
                                                @foreach($ageGroups as $ageGroup)
                                                    @if($ageGroup->id != $book->age_group_id)
                                                        <option value = {{ $ageGroup->id }} >
                                                            {{ $ageGroup->age_group }}
                                                        </option>
                                                    @endif
                                                @endforeach
                                            </select>
                                            @error('age_group')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Current Cover') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <div>
                                                <img class="rounded pr-1 pb-1" alt="Book Cover" src="{{ asset('images/' . $book->cover_url) }}" style="width:200px;"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('New Cover (.jpg File)') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <div>
                                                <label for="cover_url"></label>
                                                <input
                                                    type="file"
                                                    id="cover_url"
                                                    name="cover_url"
                                                    autocomplete="cover_url"
                                                    placeholder="Book's cover_url"
                                                    value="{{ old('cover_url') }}"
                                                    aria-describedby="nameHelp">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Current Pages') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            @foreach($book->pages as $page)
                                                <img class="rounded pr-1 pb-1" src="{{ asset('images/' . $page->page_image_url) }}" style="width:100px"/>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('New Pages (.jpg Files)') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <div>
                                                <label for="page_image_url"></label>
                                                <input
                                                    type="file"
                                                    multiple="multiple"
                                                    id="page_image_url"
                                                    name="page_image_url[]"
                                                    autocomplete="page_image_url"
                                                    placeholder="Book's pages"
                                                    value="{{ old('page_image_url') }}"
                                                    aria-describedby="nameHelp">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                @if($page->audio_url)
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Current Audio') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                @foreach($book->pages as $page)
                                                    <div>
                                                        <div>Audio from Page {{$page->page_index}}</div>
                                                        <audio
                                                            id="audio"
                                                            controls
                                                            class="rounded pr-1 pb-1"
                                                            src={{ asset('audios/' . $page->audio_url) }}>
                                                            Your browser does not support the
                                                            <code>audio</code> element.
                                                        </audio>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                @endif

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Add Audio (.mp3 Files)') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <div>
                                                <label for="audio_url"></label>
                                                <input
                                                    type="file"
                                                    multiple="multiple"
                                                    id="audio_url"
                                                    name="audio_url[]"
                                                    autocomplete="audio_url"
                                                    placeholder="Page's Audios"
                                                    value="{{ old('audio_url') }}"
                                                    aria-describedby="nameHelp">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Video') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            @if($book->video)
                                                <input
                                                    type="text"
                                                    id="video_url"
                                                    name="video_url"
                                                    autocomplete="video_url"
                                                    placeholder="Youtube URL. Has to be an URL like https://www.youtube.com/embed/..."
                                                    class="form-control @error('read time') is-invalid @enderror"
                                                    value="{{$book->video->video_url}}"
                                                    aria-describedby="nameHelp">
                                                <br>
                                                <iframe class="rounded"
                                                        width="280" height="157,5"
                                                        src="{{$book->video->video_url}}"
                                                        frameborder="0" gesture="media"
                                                        allow="autoplay; encrypted-media"
                                                        allowfullscreen>
                                                </iframe>
                                            @else
                                                <input
                                                    type="text"
                                                    id="new_video_url"
                                                    name="new_video_url"
                                                    autocomplete="new_video_url"
                                                    placeholder="Youtube URL. Has to be an URL like https://www.youtube.com/embed/..."
                                                    class="form-control @error('read time') is-invalid @enderror"
                                                    value="{{old('new_video_url')}}"
                                                    aria-describedby="nameHelp">
                                            @endif
                                            @error('new_video_url')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Activites') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <select name="activity_id[]" class="form-control" multiple style="height:230px">
                                                {{$currentActivities[] = ''}}
                                                @foreach($book->activityBooks as $activityBook)
                                                    {{$currentActivities[] = $activityBook->activity->id}}
                                                @endforeach
                                                @foreach($activities as $activity)
                                                    @if(in_array($activity->id, $currentActivities))
                                                        <option selected value = {{ $activity->id }} >
                                                            {{ $activity->title }}
                                                        </option>
                                                    @else
                                                        <option value = {{ $activity->id }} >
                                                            {{ $activity->title }}
                                                        </option>
                                                    @endif
                                                @endforeach
                                            </select>
                                            @error('author')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Is Active') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <select name="is_active" class="form-control">
                                                @if($book->is_active == 1)
                                                    <option selected value = 1 > Yes </option>
                                                    <option value = 0 > No </option>
                                                @else
                                                    <option value = 1 > Yes </option>
                                                    <option selected value = 0 > No </option>
                                                @endif
                                            </select>
                                            @error('is_active')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Access Level') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <select name="access_level" class="form-control">
                                                @if($book->access_level == 1)
                                                    <option selected value = 1 > Premium </option>
                                                    <option value = 0 > Free </option>
                                                @else
                                                    <option value = 1 > Premium </option>
                                                    <option selected value = 0 > Free </option>
                                                @endif
                                            </select>
                                            @error('access_level')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Inserted by') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input
                                                type="text"
                                                disabled
                                                id="user_id"
                                                name="user_id"
                                                autocomplete="user_id"
                                                placeholder="user_id"
                                                class="form-control
                                                @error('user_id') is-invalid @enderror"
                                                value="{{ $book->user->first_name }} {{ $book->user->last_name }}"
                                                required
                                                aria-describedby="nameHelp">
                                            @error('user_id')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Created At') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input
                                                type="text"
                                                disabled
                                                id="created_at"
                                                name="created_at"
                                                autocomplete="created_at"
                                                placeholder="created_at"
                                                class="form-control @error('created at') is-invalid @enderror"
                                                value="{{ $book->created_at }}"
                                                required
                                                aria-describedby="nameHelp">

                                            @error('created_at')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Updated At') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input
                                                type="text"
                                                disabled
                                                id="updated_at"
                                                name="updated_at"
                                                autocomplete="updated_at"
                                                placeholder="updated_at"
                                                class="form-control
                                    @error('updated at') is-invalid @enderror"
                                                value="{{ $book->updated_at }}"
                                                required
                                                aria-describedby="nameHelp">

                                            @error('updated_at')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="d-flex justify-content-center">
                            <button type="submit" class="btn btn-success">Update</button>
                            <a href="{{url('books/')}}" type="button" class="btn btn-danger">Return</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        FilePond.registerPlugin(FilePondPluginImagePreview);

        const inputCover = document.querySelector('input[id="cover_url"]');
        const pondCover = FilePond.create( inputCover );

        pondCover.setOptions({
            allowMultiple: false,
            instantUpload: false,
            server: {
                url : '/upload',
                headers : {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            }
        });

        const inputPages = document.querySelector('input[id="page_image_url"]');
        const pondPages = FilePond.create( inputPages );

        pondPages.setOptions({
            allowMultiple:  true,
            instantUpload:  false,
            allowReorder:   true,
            server: {
                url : '/upload',
                headers : {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            },
        });

        const inputAudio = document.querySelector('input[id="audio_url"]');
        const pondAudio = FilePond.create( inputAudio );

        pondAudio.setOptions({
            allowMultiple:  true,
            instantUpload:  false,
            allowReorder:   true,
            server: {
                url : '/upload',
                headers : {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            }
        });

    </script>
@endsection
