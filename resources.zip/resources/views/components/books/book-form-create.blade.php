@section('content')
{{--    <head>--}}
{{--        <link href="https://unpkg.com/filepond/dist/filepond.css" rel="stylesheet" >--}}
{{--    </head>--}}

    <body>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <form method="POST" action="{{ url('admin/books')}}">
                            @csrf
                            <div class="card ">

                                <div class="card-header card-header-primary">
                                    <h4 class="card-title">{{ __('Create Book') }}</h4>
                                    <p class="card-category">{{ __('Book information') }}</p>
                                </div>

                                <div class="card-body">
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Title') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <input
                                                    type="text"
                                                    id="title"
                                                    name="title"
                                                    autocomplete="title"
                                                    placeholder="Book's name"
                                                    class="form-control
                                                     @error('title') is-invalid @enderror"
                                                    value="{{ old('title') }}"
                                                    required
                                                    aria-describedby="nameHelp">
                                                @error('title')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Author(s)') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <select name="author_id[]" class="form-control" multiple style="height:230px">
                                                    @foreach($authors as $author)
                                                        <option value="{{ $author->id }}">
                                                            {{ $author->first_name }} {{ $author->last_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @error('author')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Description') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <textarea
                                                    type="text"
                                                    rows="6"
                                                    id="description"
                                                    name="description"
                                                    placeholder="Describe the book in a few sentences"
                                                    autocomplete="description"
                                                    class="form-control @error('description') is-invalid @enderror"
                                                    required
                                                    aria-describedby="nameHelp">{{ old('description') }}</textarea>
                                                @error('description')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Read Time (Min)') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <input
                                                    type="text"
                                                    id="read_time"
                                                    name="read_time"
                                                    autocomplete="read_time"
                                                    placeholder="Estimated reading time in minutes"
                                                    class="form-control @error('read time') is-invalid @enderror"
                                                    value="{{ old('read_time') }}"
                                                    required
                                                    aria-describedby="nameHelp">
                                                @error('read_time')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Age Group (Years)') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <select name="age_group_id" class="form-control">
                                                    @foreach($ageGroups as $ageGroup)
                                                        <option value = {{ $ageGroup->id }} >
                                                            {{ $ageGroup->age_group }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @error('age_group')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Cover Image (.jpg File)')}}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <div>
                                                    <label for="cover_url"></label>
                                                    <input
                                                        type="file"
                                                        id="cover_url"
                                                        name="cover_url"
                                                        autocomplete="cover_url"
                                                        placeholder="Book's cover_url"
{{--                                                        class="form-control @error('cover_url') is-invalid @enderror"--}}
                                                        value="{{ old('cover_url') }}"
                                                        required
                                                        aria-describedby="nameHelp">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __("Pages Images (.jpg Files)") }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <div>
                                                    <label for="page_image_url"></label>
                                                    <input
                                                        type="file"
                                                        multiple="multiple"
                                                        id="page_image_url"
                                                        name="page_image_url[]"
                                                        autocomplete="page_image_url"
                                                        placeholder="Book's pages"
                                                        value="{{ old('page_image_url') }}"
                                                        required
                                                        aria-describedby="nameHelp">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Pages Audio (.mp3 Files)') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <div>
                                                    <label for="audio_url"></label>
                                                    <input
                                                        type="file"
                                                        multiple="multiple"
                                                        id="audio_url"
                                                        name="audio_url[]"
                                                        autocomplete="audio_url"
                                                        placeholder="Pages's Audio"
                                                        value="{{ old('audio_url') }}"
                                                        aria-describedby="nameHelp">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Video') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <input
                                                    type="text"
                                                    rows="2"
                                                    id="video_url"
                                                    name="video_url"
                                                    autocomplete="video_url"
                                                    placeholder="Youtube URL. Has to be an URL like https://www.youtube.com/embed/..."
                                                    class="form-control @error('read time') is-invalid @enderror"
                                                    value="{{ old('video_url') }}"
                                                    required
                                                    aria-describedby="nameHelp">
                                                @error('read_time')
                                                <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Activities') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <select name="activity_id[]" class="form-control" multiple style="height:230px">
                                                    @foreach($activities as $activity)
                                                        <option value="{{ $activity->id }}">
                                                            {{ $activity->title }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @error('activities')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                        <div class="row">
                                            <label class="col-sm-2 col-form-label">{{ __('Is Active') }}</label>
                                            <div class="col-sm-7">
                                                <div class="form-group">
                                                    <select name="is_active" class="form-control">
                                                        <option selected Value = 1> Yes </option>
                                                        <option value = 0> No </option>
                                                    </select>
                                                    @error('is_active')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Access Level') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <select name="access_level" class="form-control">
                                                        <option selected value = 0>
                                                            Free
                                                        </option>
                                                        <option value = 1>
                                                            Premium
                                                        </option>
                                                </select>
                                                @error('$book->access_level')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Inserted by') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <input
                                                    type="text"
                                                    id="user_id"
                                                    name="user_id"
                                                    autocomplete="user_id"
                                                    placeholder="User ID"
                                                    class="form-control
                                                    @error('user_id') is-invalid @enderror"
                                                    value="{{ old('user_id') }}"
                                                    required
                                                    aria-describedby="nameHelp">

                                                @error('user_id')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                            <div class="d-flex justify-content-center">
                                <button type="submit" class="btn btn-success" style="width:100px">Save</button>
                                <a href="{{url('books/')}}" type="button" class="btn btn-danger" style="width:100px">Return</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
@endsection
@section('scripts')
    <script>
        FilePond.registerPlugin(FilePondPluginImagePreview);

        const inputCover = document.querySelector('input[id="cover_url"]');
        const pondCover = FilePond.create( inputCover );

        pondCover.setOptions({
            allowMultiple: false,
            instantUpload: false,
            server: {
                url : '/upload',
                headers : {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            }
        });

        const inputPages = document.querySelector('input[id="page_image_url"]');
        const pondPages = FilePond.create( inputPages );

        pondPages.setOptions({
            allowMultiple:  true,
            instantUpload:  false,
            allowReorder:   true,
            server: {
                url : '/upload',
                headers : {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            },
        });

        const inputAudio = document.querySelector('input[id="audio_url"]');
        const pondAudio = FilePond.create( inputAudio );

        pondAudio.setOptions({
            allowMultiple:  true,
            instantUpload:  false,
            allowReorder:   true,
            server: {
                url : '/upload',
                headers : {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            }
        });

    </script>
@endsection
