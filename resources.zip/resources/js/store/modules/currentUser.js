import axios from "axios"
import router from '../../routers'
const state = {
    user: {}
}
const actions = {
    getUser({commit}){
        axios
        .get('api/user/current')
        .then(response => {
            commit('setUser', response.data)
        })
    },
    loginUser({}, user){
        axios
        .post('/api/login', {
            user_name: user.user_name,
            password: user.password
        })
        .then(response => {
            if(response.data.access_token){
                //guardar token
                localStorage.setItem('token', response.data.access_token)
                router.push({
                    name: 'Dashboard'
                })
            } else{

            }
        })
    }
}
const mutations = {
    setUser(state, data){
        state.user = data
    }
}
const getters = {}

export default {
    namespaced: true,
    state,
    actions,
    mutations,
    getters
}