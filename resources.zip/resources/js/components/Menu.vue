<template>
    <nav class="navbar navbar-expand-lg bg-dark fixed-top">
      <div class="container">
        <router-link :to="{name: 'Home'}" class="navbar-brand logo">StoryTail</router-link>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <router-link :to="{name: 'Login'}" aria-current="page" class="nav-link active">Sign In</router-link>
            </li>
            <li class="nav-item">
              <router-link :to="{name: 'Signup'}" class="btn btn-orange ml-2">Register</router-link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
   
</template>

<script>
export default {
    name: 'Menu'
}
</script>

<style>

</style>