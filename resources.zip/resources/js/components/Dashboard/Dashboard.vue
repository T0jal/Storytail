<template>
  <div>Dashboard {{currentUser}}</div>
</template>

<script>
export default {
  computed: {
    currentUser:{
      get(){
          return this.$store.state.currentUser.user
      }
    }
  },
  created(){
    axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token')
    this.$store.dispatch('currentUser/getUser')
  }
}
</script>
<style>

</style>