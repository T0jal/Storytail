<template>
<div>
<Menu />
<flipbook class="flipbook" :key="forceRendering" :singlePage="forceRendering" :pages="pages"  v-slot="flipbook">
  <div class="action-bar">
     <button
          class="btn-orange btn left"
          :class="{ disabled: (flipbook.page<=2) }"
          @click="flipBtn(flipbook.flipLeft, flipbook.page, flipbook.numPages)"
        ><i class="fas fa-caret-left"></i></button>
        <button
          class="btn-orange btn plus"
          :class="{ disabled: !flipbook.canZoomIn }"
          @click="flipbook.zoomIn"
        ><i class="fas fa-plus"></i></button>
        <!-- <span class="page-num">
          Page {{ flipbook.page }} of {{ flipbook.numPages }}
        </span> -->
        <button class="btn-black btn minus" v-show="flipbook.page == flipbook.numPages">Finish Read</button>
        <button
          class="btn-orange btn minus"
          :class="{ disabled: !flipbook.canZoomOut }"
          @click="flipbook.zoomOut"
        ><i class="fas fa-minus"></i></button>
        <button
          class="btn-orange btn right"
          :class="{ disabled: (flipbook.page >= flipbook.numPages) }"
          @click="flipBtn(flipbook.flipRight, flipbook.page, flipbook.numPages)"
        ><i class="fas fa-caret-right"></i></button>
        <button
          class="btn-orange btn audio"
          @click="startAudio(flipbook.page, flipbook.numPages)"
        ><i :class="[(isAudio)?'fas fa-volume-mute':'fas fa-volume-up']"></i></button>
                <!-- <span class="page-num">
          Page {{ flipbook.page }} of {{ flipbook.numPages }}
        </span>         -->
  </div>
  </flipbook>
</div>
</template>

<script>
import Flipbook from 'flipbook-vue'
import Menu from './Menu'
export default {
  props: ['id', 'book'],
  data(){
    return{
      pages: [],
      audios: [],
      isAudio: false,
      forceRendering: false,
      audio: new Audio()
    }
  },
  methods: {
    createBook(){
      this.pages.push(null)
      this.pages.push(`images/${this.book.cover_url}`)
      this.book.pages.forEach(el => {
        this.audios.push(`audios/${el.audio_url}`)
        this.pages.push(`images/${el.page_image_url}`)
      });
    },
    playAudio(url){
      return new Promise((resolve,reject)=>{
        let audio = this.audio;
        audio.preload = "auto";                      // intend to play through
        audio.autoplay = true;                       // autoplay when loaded
        audio.onerror = reject;                      // on error, reject
        audio.onended = resolve;                     // when done, resolve
        audio.src = url;
      })
    },
    startAudio(page,pages){
      if(this.forceRendering){
        if(page > 1 && page <= pages){
          this.isAudio = (this.isAudio)?false:true;
          if(this.isAudio){
            this.playAudio(this.audios[page-2]);
          } else{
          this.audio.pause();
          }
          console.log('Audio is ',this.isAudio,page-2,pages-2)
        }
      } else{
        this.forceRendering = true
      }
    },
    flipBtn(flip,page,pages){
      if(this.isAudio){
        this.audio.pause();
        this.playAudio(this.audios[page-2]);
      }
      return flip()
    }
  },
  mounted(){
    this.createBook();
  },    
  components: {Flipbook, Menu}
}
</script>

<style scoped>
#b{
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  color: #ccc;
  overflow: hidden;
}

a {
  color: inherit;
}
.btn-black{
  background-color: #000;
  color: #fff;
  font-weight: 600;
}
.action-bar {
  width: 100%;
  height: 30px;
  padding: 100px 0 30px 0;
  display: flex;
  justify-content: center;
  align-items: center;
}
.action-bar .btn {
  font-size: 12px;
}
.action-bar .btn svg {
  bottom: 0;
}
.action-bar .btn:not(:first-child) {
  margin-left: 10px;
}
.has-mouse .action-bar .btn:hover {
  color: #ccc;
  filter: drop-shadow(1px 1px 5px #000);
  cursor: pointer;
}
.action-bar .btn:active {
  filter: none !important;
}
.action-bar .btn.disabled {
  color: #fff;
  pointer-events: none;
}
.action-bar .page-num {
  font-size: 12px;
  margin-left: 10px;
}
.flipbook  {
  width: 90vw;
  height: calc(100vh - 200px);
}
.flipbook .bounding-box {
  box-shadow: 0 0 20px #000;
}
</style>