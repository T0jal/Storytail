<template>
  <div>
      <Menu/>
      <br><br><br><br>
       {{author}}
        <section class="container p-3 mt-5">
        <div class="row">
          <div class="col-lg-3">
            <img class="card-img-top" :src="`images/${author.author_photo_url}`" alt="Card image cap">
          </div>
          <div class="col-lg-9">
            <h1 class="bold">{{author.first_name}}</h1>
            <h4 class="bold">Nacionality 
              <span class="author-link">{{author.nationality}}</span>
            </h4>

            <p class="mt-4">{{author.description}}</p>
          </div>
        </div>
    </section>
  </div>
</template>

<script>
import Menu from './Menu'
export default {
    props: ['id'],
    data(){
        return{
            author: []
        }
    },
    methods: {
        async fetchBook(id){
        const res = await fetch(`/api/authors/${id}`);
        const data = await res.json();
        console.log(data)
        return data.data;
        },
    },
    async mounted(){
        this.author = await this.fetchBook(this.id)
    },
    components: {Menu},
}
</script>

<style scoped>
section{
    margin: 50px;
    background: #fff;
}
.author-link{
  color: var(--orange-100);
}
</style>