<template>
<div class="card m-3">
            <div class="card-title">
                <h3>{{book.title}}</h3>
            </div>
            <img class="card-img-top" :src="'/images/'+book.cover_url" alt="Card image cap">
            <div class="card-body d-flex justify-content-center">
                <router-link :to="{name: 'BookDetails', params:{id: book.id}}" class="btn btn-orange btn-sm">Read</router-link>
            </div>
</div>  
</template>

<script>
export default {
    name: 'Book',
    props: {
        book: null
    }
}
</script>

<style>
</style>