<template>
<div>
    <Menu/>
    <div id="login">
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form @submit.prevent="sendForm" id="login-form" class="form">
                            <div class="row">
                                <div class="col">
                                     <label for="firstname">Firstname:</label>
                                     <input type="text" v-model="first_name" id="firstname" class="form-control">
                                </div>
                                <div class="col">
                                    <label for="lastname">Lastname:</label>
                                    <input type="text" v-model="last_name" id="lastname" class="form-control">
                                </div>
                            </div>
                            <div class="mt-3">
                                <label for="username">Username:</label>
                                <input type="text" v-model="user_name" id="username" class="form-control">
                            </div>
                            <div class="mt-3">
                                <label for="email">Email:</label>
                                <input type="text" v-model="email" id="email" class="form-control">
                            </div>
                            <div class="mt-3">
                                <label for="password">Password:</label>
                                <input type="text" v-model="password" id="password" class="form-control">
                            </div>
                            <div class="mt-3">
                                <label for="password">Confirm Password:</label>
                                <input type="text" v-model="password_confirm" id="password" class="form-control">
                            </div>
                            <div class="form-group">
                                <br>
                                <input type="submit" name="submit" class="btn btn-orange btn-md" value="submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import Menu from './Menu'
export default {
    name: 'Signup',
    components: {Menu},
    data() {
        return{
            first_name: '',
            last_name: '',
            user_name: '',
            email: '',
            password: '',
            password_confirm: ''
        }
    },
    methods: {
        sendForm(){
            const data = {
                first_name: this.first_name,
                last_name: this.last_name,
                user_name: this.user_name,
                email: this.email,
                password: this.password,
                password_confirm: this.password_confirm
            }
            console.log(data)
        }
    }

}
</script>

<style scoped>
.text-logo{
    font-family: babyeliot;
    color: white;
}
#login{
    background: white;
    padding: 100px 0 0 0;
    height: 100vh;
}
#login .container #login-row #login-column #login-box {
  margin-top: 120px;
  max-width: 600px;
  background-color: var(--grey-100);
}
#login .container #login-row #login-column #login-box #login-form {
  padding: 20px;
}
#login .container #login-row #login-column #login-box #login-form #register-link {
  margin-top: -85px;
}
</style>